import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Character {
  id: number;
  name: string;
  title: string;
  emoji: string;
  age: string;
  description: string[];
  bgColor: string;
  textColor: string;
}

interface CharacterContextType {
  characters: Character[];
  selectedCharacter: Character | null;
  setSelectedCharacter: (character: Character | null) => void;
  currentIndex: number;
  setCurrentIndex: (index: number) => void;
}

const CharacterContext = createContext<CharacterContextType | undefined>(undefined);

export const useCharacter = () => {
  const context = useContext(CharacterContext);
  if (!context) {
    throw new Error('useCharacter must be used within a CharacterProvider');
  }
  return context;
};

const characters: Character[] = [
  {
    id: 1,
    name: 'Parveen Saeed',
    title: 'The Dreamer',
    emoji: '👩',
    age: 'Late 30s',
    description: [
      'Parveen grew up in the narrow streets of Khamanon and Nandan Village.',
      'Once wanted films, became a tech leader in New York.',
      'Loving wife and mother, heart still in Punjab.',
      'Determined to revive DDLJ in Punjabi with her team.'
    ],
    bgColor: 'from-pink-400 to-rose-500',
    textColor: 'text-white'
  },
  {
    id: 2,
    name: 'Azka Saeed',
    title: 'The Confidante',
    emoji: '👩',
    age: 'Late 30s',
    description: [
      'Azka is Parveen\'s childhood friend and first cousin.',
      'A humble, conservative, and down-to-earth schoolteacher who has never lived outside Khamanon.',
      'Married early, she leads a simple family life but is Parveen\'s unwavering support system.',
      'Known for her uncanny sixth sense and quiet wisdom.'
    ],
    bgColor: 'from-emerald-400 to-teal-500',
    textColor: 'text-white'
  },
  {
    id: 3,
    name: 'Abdul',
    title: 'The Reluctant Filmmaker',
    emoji: '📸',
    age: 'Early 30s',
    description: [
      'Azka\'s younger brother, in his early 30s.',
      'A professional photographer who moved to New Delhi to earn a living.',
      'Once dreamed of becoming a filmmaker but settled into a corporate technical role.',
      'Happy-go-lucky yet ambitious—ready to pause his career and help Parveen chase her mission of remaking DDLJ in Punjabi.'
    ],
    bgColor: 'from-blue-400 to-indigo-500',
    textColor: 'text-white'
  },
  {
    id: 4,
    name: 'Anil Sharma aka Annu Bhaiya',
    title: 'The Cineplex King',
    emoji: '🎬',
    age: 'Around 50',
    description: [
      'A youth leader turned cinema owner.',
      'Runs the only cineplex in Fatehpur Sahib district, located in Nandan Village near Khamanon.',
      'Passionate about movies and remembered for taking bold risks in the mid-90s.',
      'Both loved and blamed—Sardaar Barnala still holds him responsible for "ruining a generation" with his choices.'
    ],
    bgColor: 'from-purple-400 to-violet-500',
    textColor: 'text-white'
  },
  {
    id: 5,
    name: 'Abhay Shekhawat',
    title: 'The Visionary',
    emoji: '💼',
    age: 'Mid-40s',
    description: [
      'Parveen\'s mentor and the towering figure behind Shekhawat Communications.',
      'Sharp, ambitious, and suave—he migrated from Punjab to NCR and eventually settled in New York to expand his empire.',
      'A risk-taker who trusts his people deeply, including Parveen.',
      'His bold decisions shaped not only his company\'s future but also the direction of many lives around him.'
    ],
    bgColor: 'from-amber-400 to-orange-500',
    textColor: 'text-white'
  },
  {
    id: 6,
    name: 'Jai Prakash (JP)',
    title: 'The Steady Hand',
    emoji: '🧑‍💻',
    age: 'Late 40s',
    description: [
      'The dependable right-hand man to Abhay Shekhawat.',
      'VP Engineering at Shekhawat Communications.',
      'Prefers staying in the background, focusing on running operations smoothly.',
      'The calm anchor to Abhay\'s ambitious storms.'
    ],
    bgColor: 'from-slate-400 to-gray-500',
    textColor: 'text-white'
  },
  {
    id: 7,
    name: 'Sardaar Baldev Singh Barnala',
    title: 'The Rigid Patriarch',
    emoji: '👳',
    age: '70 years',
    description: [
      'Once the principal of Khamanon\'s only college, now the powerful village head.',
      'Strong-willed, adamant, and unbending in his principles.',
      'Lifelong rival of Annu Bhaiya.',
      'His only daughter skipped her Canadian dream at the last moment, swayed instead by the magic of DDLJ in London.'
    ],
    bgColor: 'from-red-400 to-rose-500',
    textColor: 'text-white'
  },
  {
    id: 8,
    name: 'Faddey Bhajiyewala',
    title: 'The Street-smart Survivor',
    emoji: '🍲',
    age: '60 years',
    description: [
      'Famous snack seller of Khamanon.',
      'Struck gold by black-marketing DDLJ tickets during its craze years.',
      'A master opportunist, he became the first man from Khamanon to visit Switzerland.',
      'Loved for his bhajiyas, remembered for his wit.'
    ],
    bgColor: 'from-yellow-400 to-amber-500',
    textColor: 'text-gray-800'
  },
  {
    id: 9,
    name: 'Imran',
    title: 'The Steady Dreamer',
    emoji: '🍴',
    age: 'Early 40s',
    description: [
      'Early 40s, rooted yet restless.',
      'Runs a buzzing restaurant in Jersey Town.',
      'Loving husband to Parveen, doting father.',
      'Dreams of settling in Karachi with a food chain.'
    ],
    bgColor: 'from-green-400 to-emerald-500',
    textColor: 'text-white'
  }
];

interface CharacterProviderProps {
  children: ReactNode;
}

export const CharacterProvider: React.FC<CharacterProviderProps> = ({ children }) => {
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  return (
    <CharacterContext.Provider
      value={{
        characters,
        selectedCharacter,
        setSelectedCharacter,
        currentIndex,
        setCurrentIndex,
      }}
    >
      {children}
    </CharacterContext.Provider>
  );
};