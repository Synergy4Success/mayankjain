import React from 'react';
import { BookOpen, Users } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section className="mb-12">
      <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 border border-orange-100">
        <div className="flex items-center justify-center mb-6">
          <div className="bg-gradient-to-r from-orange-400 to-red-500 p-4 rounded-full">
            <BookOpen className="w-8 h-8 text-white" />
          </div>
        </div>
        
        <h2 className="text-2xl md:text-3xl font-bold text-gray-800 text-center mb-6">
          About the Characters
        </h2>
        
        <div className="max-w-4xl mx-auto">
          <p className="text-lg text-gray-700 leading-relaxed text-center mb-8">
            Every great story lives through its characters. Here are the people who bring the world of 
            <span className="font-semibold text-orange-600"> DDLJ – A Fitoor </span>
            alive—each one carrying their own quirks, passions, and secrets from the galliyan of Khamanon 
            to the corridors of Shekhawat Communications.
          </p>
          
          <div className="flex items-center justify-center space-x-2 text-orange-600">
            <Users className="w-5 h-5" />
            <span className="font-medium">9 Unique Characters</span>
            <Users className="w-5 h-5" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;