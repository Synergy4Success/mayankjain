import React from 'react';
import { ExternalLink, Search, Play, ShoppingCart } from 'lucide-react';

interface CTAButtonProps {
  text: string;
  onClick: () => void;
  variant?: 'primary' | 'search' | 'video' | 'secondary';
  large?: boolean;
}

const CTAButton: React.FC<CTAButtonProps> = ({ 
  text, 
  onClick, 
  variant = 'primary',
  large = false 
}) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'search':
        return 'bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white';
      case 'video':
        return 'bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white';
      case 'secondary':
        return 'bg-gradient-to-r from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700 text-white';
      default:
        return 'bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white';
    }
  };

  const getIcon = () => {
    switch (variant) {
      case 'search':
        return <Search className="w-5 h-5" />;
      case 'video':
        return <Play className="w-5 h-5" />;
      case 'primary':
        return <ShoppingCart className="w-5 h-5" />;
      default:
        return <ExternalLink className="w-5 h-5" />;
    }
  };

  const sizeClasses = large 
    ? 'px-8 py-4 text-lg font-bold' 
    : 'px-6 py-3 text-base font-semibold';

  return (
    <button
      onClick={onClick}
      className={`
        ${getVariantStyles()}
        ${sizeClasses}
        rounded-full
        shadow-lg
        hover:shadow-xl
        transform
        hover:scale-105
        transition-all
        duration-300
        flex
        items-center
        space-x-2
        group
        animate-pulse
        hover:animate-none
      `}
    >
      <span>{text}</span>
      <div className="group-hover:translate-x-1 transition-transform duration-300">
        {getIcon()}
      </div>
    </button>
  );
};

export default CTAButton;