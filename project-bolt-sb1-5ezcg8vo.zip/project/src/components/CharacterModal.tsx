import React from 'react';
import { X, MapPin, Briefcase, Heart } from 'lucide-react';
import { useCharacter } from '../context/CharacterContext';

const CharacterModal: React.FC = () => {
  const { selectedCharacter, setSelectedCharacter } = useCharacter();

  if (!selectedCharacter) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-in fade-in zoom-in duration-300">
        <div className={`bg-gradient-to-br ${selectedCharacter.bgColor} p-8 rounded-t-3xl relative`}>
          <button
            onClick={() => setSelectedCharacter(null)}
            className="absolute top-4 right-4 bg-white/20 hover:bg-white/30 rounded-full p-2 transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
          
          <div className="text-center">
            <div className="text-8xl mb-4">
              {selectedCharacter.emoji}
            </div>
            <h2 className={`text-3xl font-bold mb-2 ${selectedCharacter.textColor}`}>
              {selectedCharacter.name}
            </h2>
            <p className={`text-xl font-medium ${selectedCharacter.textColor} opacity-90`}>
              {selectedCharacter.title}
            </p>
          </div>
        </div>
        
        <div className="p-8">
          <div className="flex items-center justify-center mb-6">
            <div className="bg-gray-100 rounded-full px-4 py-2 flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-700">
                Age: {selectedCharacter.age}
              </span>
            </div>
          </div>
          
          <div className="space-y-4">
            {selectedCharacter.description.map((paragraph, index) => (
              <div
                key={index}
                className="flex items-start space-x-3 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
              >
                <div className="bg-orange-500 rounded-full p-1 mt-1 flex-shrink-0">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <p className="text-gray-700 leading-relaxed">
                  {paragraph}
                </p>
              </div>
            ))}
          </div>
          
          <div className="mt-8 pt-6 border-t border-gray-200">
            <div className="flex items-center justify-center space-x-2 text-orange-600">
              <Heart className="w-5 h-5" />
              <span className="text-sm font-medium">Part of DDLJ – A Fitoor</span>
              <Heart className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CharacterModal;