import React from 'react';
import { useCharacter } from '../context/CharacterContext';

interface Character {
  id: number;
  name: string;
  title: string;
  emoji: string;
  age: string;
  description: string[];
  bgColor: string;
  textColor: string;
}

interface CharacterCardProps {
  character: Character;
  index: number;
}

const CharacterCard: React.FC<CharacterCardProps> = ({ character, index }) => {
  const { setSelectedCharacter } = useCharacter();

  return (
    <div
      className="group cursor-pointer transform transition-all duration-300 hover:scale-105 hover:-translate-y-2"
      onClick={() => setSelectedCharacter(character)}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className={`bg-gradient-to-br ${character.bgColor} rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 h-full`}>
        <div className="text-center">
          <div className="text-6xl mb-4 transform group-hover:scale-110 transition-transform duration-300">
            {character.emoji}
          </div>
          
          <h3 className={`text-xl font-bold mb-2 ${character.textColor}`}>
            {character.name}
          </h3>
          
          <p className={`text-sm font-medium mb-3 ${character.textColor} opacity-90`}>
            {character.title}
          </p>
          
          <div className={`text-xs ${character.textColor} opacity-75 mb-4`}>
            Age: {character.age}
          </div>
          
          <div className={`text-sm ${character.textColor} opacity-90 line-clamp-3`}>
            {character.description[0]}
          </div>
          
          <div className="mt-4 pt-4 border-t border-white/20">
            <span className={`text-xs ${character.textColor} opacity-75 hover:opacity-100 transition-opacity`}>
              Click to learn more →
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CharacterCard;