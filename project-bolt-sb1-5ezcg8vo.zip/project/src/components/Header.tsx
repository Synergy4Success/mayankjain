import React from 'react';
import { Star, Heart } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-red-600 via-orange-500 to-amber-500 text-white shadow-lg">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-center space-x-3">
          <Star className="w-8 h-8 text-yellow-200 animate-pulse" />
          <h1 className="text-3xl md:text-4xl font-bold text-center">
            The Characters of DDLJ – A Fitoor
          </h1>
          <Heart className="w-8 h-8 text-pink-200 animate-pulse" />
        </div>
        <p className="text-center mt-2 text-orange-100 text-lg">
          Meet the souls behind the story
        </p>
      </div>
    </header>
  );
};

export default Header;