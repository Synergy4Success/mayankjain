import React from 'react';
import { Book, Heart, Star } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gradient-to-r from-gray-800 to-gray-900 text-white py-12 mt-16">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <Book className="w-8 h-8 text-orange-400" />
            <h3 className="text-2xl font-bold">DDLJ – A Fitoor</h3>
            <Star className="w-8 h-8 text-yellow-400" />
          </div>
          
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto leading-relaxed">
            Together, these characters—dreamers, mentors, rivals, and survivors—make DDLJ – A Fitoor 
            more than just a story. They are fragments of a world where nostalgia meets ambition, 
            and where every small town carries big dreams.
          </p>
          
          <div className="flex items-center justify-center space-x-2 text-pink-400">
            <Heart className="w-5 h-5" />
            <span className="text-sm">#Three Decades of DDLJ. One Decade of a Fitoor.</span>
            <Heart className="w-5 h-5" />
          </div>
          
          <div className="mt-8 pt-6 border-t border-gray-700">
            <p className="text-gray-400 text-sm">
              © 2025 DDLJ – A Fitoor. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;