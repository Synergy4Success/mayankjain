import React from 'react';
import { useCharacter } from '../context/CharacterContext';
import CharacterCard from './CharacterCard';
import CharacterModal from './CharacterModal';
import CTAButton from './CTAButton';

const CharacterGrid: React.FC = () => {
  const { characters } = useCharacter();

  return (
    <div className="space-y-12">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {/* First row: 3 characters + 1 CTA */}
        {characters.slice(0, 3).map((character, index) => (
          <CharacterCard key={character.id} character={character} index={index} />
        ))}
        
        {/* CTA after first 3 characters */}
        <div className="col-span-full flex flex-col sm:flex-row justify-center items-center gap-4 my-8">
          <CTAButton
            text="Know the journey—Google #DDLJFitoor"
            onClick={() => window.open('https://www.google.com/search?q=%23DDLJFitoor', '_blank')}
            variant="search"
          />
          <CTAButton
            text="Meet the starcast 👉🏼"
            onClick={() => window.open('https://www.youtube.com/watch?v=LEcCj_VQ5Ss', '_blank')}
            variant="video"
          />
        </div>
        
        {/* Second row: 3 characters + 1 CTA */}
        {characters.slice(3, 6).map((character, index) => (
          <CharacterCard key={character.id} character={character} index={index + 3} />
        ))}
        
        {/* CTA after second 3 characters */}
        <div className="col-span-full flex flex-col sm:flex-row justify-center items-center gap-4 my-8">
          <CTAButton
            text="Meet the Starcast"
            onClick={() => window.open('https://www.youtube.com/watch?v=T46bxJ46d84', '_blank')}
            variant="video"
          />
          <CTAButton
            text="Subscribe to Fitoor Newsletter!"
            onClick={() => window.open('https://ddljfitoor.synergy4success.com/', '_blank')}
            variant="secondary"
          />
        </div>
        
        {/* Third row: 3 characters + 1 CTA */}
        {characters.slice(6, 9).map((character, index) => (
          <CharacterCard key={character.id} character={character} index={index + 6} />
        ))}
        
        {/* CTA after third 3 characters */}
        <div className="col-span-full flex flex-col sm:flex-row justify-center items-center gap-4 my-8">
          <CTAButton
            text="The Launch Video of #DDLJFitoor"
            onClick={() => window.open('https://www.youtube.com/watch?time_continue=6&v=x5G_MlJwQbs&embeds_referring_euri=https%3A%2F%2Fddljfitoor.synergy4success.com%2F&source_ve_path=Mjg2NjY', '_blank')}
            variant="video"
          />
          <CTAButton
            text="Download on Amazon Kindle!"
            onClick={() => window.open('https://www.amazon.in/DDLJ-Mayank-Jain-Kush-Bansal-ebook/dp/B08WHV8VXG', '_blank')}
            variant="primary"
          />
          <CTAButton
            text="Available in Hindi as DDLJ - एक फितूर"
            onClick={() => window.open('https://hub.synergy4success.com/web/checkout/67279b46bfce2c6a8843f66d', '_blank')}
            variant="secondary"
          />
          <CTAButton
            text="पलट पलट पलट"
            onClick={() => window.open('https://www.youtube.com/watch?v=t1E4Curfajk', '_blank')}
            variant="video"
          />
        </div>
      </div>
      
      <CharacterModal />
    </div>
  );
};

export default CharacterGrid;