import React from 'react';
import { CharacterProvider } from './context/CharacterContext';
import Header from './components/Header';
import About from './components/About';
import CharacterGrid from './components/CharacterGrid';
import Footer from './components/Footer';

function App() {
  return (
    <CharacterProvider>
      <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <About />
          <CharacterGrid />
        </main>
        <Footer />
      </div>
    </CharacterProvider>
  );
}

export default App;