import { useEffect } from 'react';
import { useCharacter } from '../context/CharacterContext';

export const useKeyboardShortcuts = () => {
  const { characters, currentIndex, setCurrentIndex, setSelectedCharacter } = useCharacter();

  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      // Prevent shortcuts when modal is open or user is typing
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) {
        return;
      }

      switch (event.key.toLowerCase()) {
        case ' ':
        case 'enter':
          event.preventDefault();
          setSelectedCharacter(characters[currentIndex]);
          break;
        case 'n':
        case 'arrowright':
          event.preventDefault();
          setCurrentIndex((currentIndex + 1) % characters.length);
          break;
        case 'p':
        case 'arrowleft':
          event.preventDefault();
          setCurrentIndex(currentIndex === 0 ? characters.length - 1 : currentIndex - 1);
          break;
        case 'escape':
          event.preventDefault();
          setSelectedCharacter(null);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [characters, currentIndex, setCurrentIndex, setSelectedCharacter]);
};