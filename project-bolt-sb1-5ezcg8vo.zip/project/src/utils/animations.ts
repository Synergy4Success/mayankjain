/**
 * Animation utility functions for the DDLJ Characters app
 */

export const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

export const staggerChildren = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export const scaleOnHover = {
  whileHover: { scale: 1.05 },
  whileTap: { scale: 0.95 }
};

/**
 * Creates a staggered animation delay for grid items
 * @param index - The index of the item in the grid
 * @param baseDelay - Base delay in milliseconds
 * @returns CSS animation delay string
 */
export const getStaggerDelay = (index: number, baseDelay: number = 100): string => {
  return `${index * baseDelay}ms`;
};

/**
 * Smooth scroll to element with offset
 * @param elementId - ID of the element to scroll to
 * @param offset - Offset from top in pixels
 */
export const smoothScrollTo = (elementId: string, offset: number = 80): void => {
  const element = document.getElementById(elementId);
  if (element) {
    const elementPosition = element.offsetTop - offset;
    window.scrollTo({
      top: elementPosition,
      behavior: 'smooth'
    });
  }
};